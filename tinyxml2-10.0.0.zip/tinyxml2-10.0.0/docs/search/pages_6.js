var searchData=
[
  ['information_0',['Read attributes and text information.',['../_example_4.html',1,'']]],
  ['information_20out_20of_20xml_1',['Get information out of XML',['../_example_3.html',1,'']]]
];
