var searchData=
[
  ['getdocument_0',['GetDocument',['../classtinyxml2_1_1_x_m_l_node.html#a6ce3bbe80357f5a4dc5db31a66f2bb18',1,'tinyxml2::XMLNode::GetDocument() const'],['../classtinyxml2_1_1_x_m_l_node.html#a48d1695f7c834129e072548957a50501',1,'tinyxml2::XMLNode::GetDocument()']]],
  ['getlinenum_1',['GetLineNum',['../classtinyxml2_1_1_x_m_l_node.html#a9b5fc636646fda761d342c72e91cb286',1,'tinyxml2::XMLNode::GetLineNum()'],['../classtinyxml2_1_1_x_m_l_attribute.html#a02d5ea924586e35f9c13857d1671b765',1,'tinyxml2::XMLAttribute::GetLineNum()']]],
  ['gettext_2',['GetText',['../classtinyxml2_1_1_x_m_l_element.html#a0fa5bea0a4daf3ddd503dcabb823eba6',1,'tinyxml2::XMLElement']]],
  ['getuserdata_3',['GetUserData',['../classtinyxml2_1_1_x_m_l_node.html#a18cc02ebd0b06f6bf5db7ef87653e00e',1,'tinyxml2::XMLNode']]]
];
